// src/components/WelcomeScreen.tsx

import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container, Typography, Box, Button, Stack,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import LanguageToggle from './LanguageToggle';

interface Props {
  lang: string;
  setLang: (lang: string) => void;
}

const WelcomeScreen: React.FC<Props> = ({ lang, setLang }) => {
  const { t } = useTranslation();
  const navigate = useNavigate(); // ✅ FIXED: Missing declaration

  return (
    <Container maxWidth="sm">
      <Box textAlign="center" mt={6}>
        <LanguageToggle lang={lang} onSelect={setLang} /> {/* ✅ Safe to pass here */}

        <Typography variant="h4" gutterBottom color="primary">
          {t('welcome')}
        </Typography>
        <Typography variant="body1" sx={{ mt: 2, mb: 4 }}>
          {t('subtitle')}
        </Typography>

        <Stack spacing={2}>
          <Button
            variant="contained"
            fullWidth
            color="primary"
            onClick={() => navigate('/mental-health')}
          >
            {t('mentalHealth')}
          </Button>
          <Button
            variant="contained"
            fullWidth
            color="secondary"
            onClick={() => navigate('/substance-use')}
          >
            {t('substanceUse')}
          </Button>
          <Button
            variant="contained"
            fullWidth
            color="success"
            onClick={() => navigate('/basic-needs')}
          >
            {t('basicNeedsT')}
          </Button>
        </Stack>
      </Box>
    </Container>
  );
};

export default WelcomeScreen;
