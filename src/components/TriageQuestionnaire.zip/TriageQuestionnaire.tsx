import React, { useState } from 'react';
import { Box, Button, Typography, RadioGroup, FormControlLabel, Radio } from '@mui/material';
import en from '../i18n/en';
import es from '../i18n/es';

type ScoreOption = 0 | 1 | 2 | 3;

const options: { labelKey: keyof typeof en; value: ScoreOption }[] = [
  { labelKey: 'never', value: 0 },
  { labelKey: 'severalDays', value: 1 },
  { labelKey: 'moreThanHalf', value: 2 },
  { labelKey: 'nearlyEveryDay', value: 3 }
];

interface Props {
  serviceType: 'Mental Health' | 'Substance Use' | 'Basic Needs';
  onResult: (result: 'Talk Now' | 'Next 48h' | 'Self-help') => void;
  onBack: () => void;
  lang: 'en' | 'es';
}

const TriageQuestionnaire: React.FC<Props> = ({ serviceType, onResult, onBack, lang }) => {
  const t = lang === 'en' ? en : es;
  const [q1, setQ1] = useState<ScoreOption | null>(null);
  const [q2, setQ2] = useState<ScoreOption | null>(null);

  const handleSubmit = () => {
    if (q1 == null || q2 == null) {
      alert('Please answer both questions');
      return;
    }
    const total = q1 + q2;
    if (total >= 3) {
      onResult('Talk Now');
    } else if (total >= 1) {
      onResult('Next 48h');
    } else {
      onResult('Self-help');
    }
  };

  return (
    <Box p={2}>
      <Button onClick={onBack}>Back</Button>
      <Typography variant="h5" gutterBottom>
        {serviceType}
      </Typography>
      <Typography>{t.phq_q1}</Typography>
      <RadioGroup
        value={q1 === null ? '' : q1}
        onChange={e => setQ1(Number(e.target.value) as ScoreOption)}
      >
        {options.map(o => (
          <FormControlLabel
            key={o.value}
            value={o.value}
            control={<Radio />}
            label={t[o.labelKey]}
          />
        ))}
      </RadioGroup>

      <Typography>{t.phq_q2}</Typography>
      <RadioGroup
        value={q2 === null ? '' : q2}
        onChange={e => setQ2(Number(e.target.value) as ScoreOption)}
      >
        {options.map(o => (
          <FormControlLabel
            key={o.value}
            value={o.value}
            control={<Radio />}
            label={t[o.labelKey]}
          />
        ))}
      </RadioGroup>

      <Button variant="contained" color="primary" fullWidth onClick={handleSubmit}>
        {lang === 'en' ? 'Submit' : 'Enviar'}
      </Button>
    </Box>
  );
};

export default TriageQuestionnaire;
